from src.database import db
from datetime import datetime

class ProjectBudget(db.Model):
    __tablename__ = "project_budgets"
    
    id = db.Column(db.Integer, primary_key=True)
    project_id = db.Column(db.Integer, db.ForeignKey("projects.id"), nullable=False)
    assigned_by = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    material_budget_total = db.Column(db.Numeric(10, 2), nullable=False)
    actual_expenses = db.Column(db.Numeric(10, 2), default=0)
    remaining_budget = db.Column(db.Numeric(10, 2), default=0)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    assigned_by_user = db.relationship("User", backref="assigned_budgets")
    
    def to_dict(self):
        return {
            "id": self.id,
            "project_id": self.project_id,
            "assigned_by": self.assigned_by,
            "material_budget_total": float(self.material_budget_total) if self.material_budget_total else 0,
            "actual_expenses": float(self.actual_expenses) if self.actual_expenses else 0,
            "remaining_budget": float(self.remaining_budget) if self.remaining_budget else 0,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None
        }


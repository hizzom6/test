from src.database import db
from datetime import datetime

class Client(db.Model):
    __tablename__ = 'clients'
    
    id = db.Column(db.Integer, primary_key=True)
    client_name = db.Column(db.String(255), nullable=False)
    city = db.Column(db.String(100), nullable=True)
    location = db.Column(db.String(255), nullable=True)
    contact_person = db.Column(db.String(255), nullable=True)
    email_1 = db.Column(db.String(255), nullable=True)
    email_2 = db.Column(db.String(255), nullable=True)
    phone_1 = db.Column(db.String(50), nullable=True)
    phone_2 = db.Column(db.String(50), nullable=True)
    notes = db.Column(db.Text, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships - using string names for forward references
    projects = db.relationship('Project', backref='client', lazy=True, cascade='all, delete-orphan')
    quotations = db.relationship('Quotation', backref='client', lazy=True, cascade='all, delete-orphan')
    invoices = db.relationship('Invoice', backref='client', lazy=True, cascade='all, delete-orphan')
    payment_tracker = db.relationship('PaymentTracker', backref='client', uselist=False, cascade='all, delete-orphan')
    
    def to_dict(self):
        return {
            'id': self.id,
            'client_name': self.client_name,
            'city': self.city,
            'location': self.location,
            'contact_person': self.contact_person,
            'email_1': self.email_1,
            'email_2': self.email_2,
            'phone_1': self.phone_1,
            'phone_2': self.phone_2,
            'notes': self.notes,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }


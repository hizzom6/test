from src.database import db
from datetime import datetime
import enum

class ProjectStatus(enum.Enum):
    QUOTED = "quoted"
    ACTIVE = "active"
    COMPLETED = "completed"

class Project(db.Model):
    __tablename__ = "projects"
    
    id = db.Column(db.Integer, primary_key=True)
    project_id = db.Column(db.String(100), unique=True, nullable=False)
    client_id = db.Column(db.Integer, db.ForeignKey("clients.id"), nullable=False)
    status = db.Column(db.Enum(ProjectStatus), nullable=False, default=ProjectStatus.QUOTED)
    start_date = db.Column(db.Date, nullable=True)
    end_date = db.Column(db.Date, nullable=True)
    progress_percentage = db.Column(db.Float, default=0.0)
    assigned_engineer_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    quotations = db.relationship("Quotation", backref="project", lazy=True)
    invoices = db.relationship("Invoice", backref="project", lazy=True)
    project_budget = db.relationship("ProjectBudget", backref="project", uselist=False, cascade="all, delete-orphan")
    payment_tracker = db.relationship("PaymentTracker", backref="project", lazy=True)
    assigned_engineer = db.relationship("User", backref="assigned_projects")
    
    def to_dict(self):
        return {
            "id": self.id,
            "project_id": self.project_id,
            "client_id": self.client_id,
            "status": self.status.value if self.status else None,
            "start_date": self.start_date.isoformat() if self.start_date else None,
            "end_date": self.end_date.isoformat() if self.end_date else None,
            "progress_percentage": self.progress_percentage,
            "assigned_engineer_id": self.assigned_engineer_id,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None
        }


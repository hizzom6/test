from src.database import db
from datetime import datetime
import enum
import json

class UserRole(enum.Enum):
    SALES = "sales"
    ACCOUNTING = "accounting"
    ENGINEERING = "engineering"
    ADMIN = "admin"

class User(db.Model):
    __tablename__ = 'users'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.String(100), unique=True, nullable=False)
    name = db.Column(db.String(255), nullable=False)
    email = db.Column(db.String(255), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    roles = db.Column(db.Text, nullable=True)  # JSON string of roles array
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def get_roles(self):
        """Parse roles JSON string to list"""
        if self.roles:
            try:
                return json.loads(self.roles)
            except json.JSONDecodeError:
                return []
        return []
    
    def set_roles(self, roles_list):
        """Convert roles list to JSON string"""
        self.roles = json.dumps(roles_list) if roles_list else None
    
    def has_role(self, role):
        """Check if user has a specific role"""
        user_roles = self.get_roles()
        return role in user_roles
    
    def can_create(self, entity_type):
        """Check if user can create specific entity based on role permissions"""
        user_roles = self.get_roles()
        
        # Admin can do everything
        if 'admin' in user_roles:
            return True
            
        # Sales permissions
        if 'sales' in user_roles:
            return entity_type in ['client', 'quotation', 'invoice']
            
        # Engineering permissions
        if 'engineering' in user_roles:
            return entity_type in ['material']
            
        return False
    
    def can_edit(self, entity_type):
        """Check if user can edit specific entity based on role permissions"""
        user_roles = self.get_roles()
        
        # Admin can do everything
        if 'admin' in user_roles:
            return True
            
        # Sales permissions
        if 'sales' in user_roles:
            return entity_type in ['client', 'quotation', 'invoice']
            
        # Accounting permissions
        if 'accounting' in user_roles:
            return entity_type in ['invoice', 'payment_tracker']
            
        # Engineering permissions
        if 'engineering' in user_roles:
            return entity_type in ['project_progress']
            
        return False
    
    def can_view(self, entity_type):
        """Check if user can view specific entity based on role permissions"""
        user_roles = self.get_roles()
        
        # Admin can do everything
        if 'admin' in user_roles:
            return True
            
        # Sales permissions
        if 'sales' in user_roles:
            return entity_type in ['client', 'quotation', 'invoice', 'payment_tracker']
            
        # Accounting permissions
        if 'accounting' in user_roles:
            return entity_type in ['invoice', 'material', 'payment_tracker']
            
        # Engineering permissions
        if 'engineering' in user_roles:
            return entity_type in ['material', 'invoice', 'project_budget']
            
        return False
    
    def to_dict(self):
        return {
            'id': self.id,
            'user_id': self.user_id,
            'name': self.name,
            'email': self.email,
            'roles': self.get_roles(),
            'is_active': self.is_active,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }


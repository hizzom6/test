from src.database import db
from datetime import datetime
import enum
import json

class QuotationStatus(enum.Enum):
    DRAFT = "draft"
    SENT = "sent"
    INCOMPLETE = "incomplete"
    EXPIRED = "expired"

class Quotation(db.Model):
    __tablename__ = "quotations"
    
    id = db.Column(db.Integer, primary_key=True)
    quotation_id = db.Column(db.String(100), unique=True, nullable=False)
    client_id = db.Column(db.Integer, db.ForeignKey("clients.id"), nullable=False)
    project_id = db.Column(db.Integer, db.ForeignKey("projects.id"), nullable=True)
    status = db.Column(db.Enum(QuotationStatus), nullable=False, default=QuotationStatus.DRAFT)
    valid_until = db.Column(db.Date, nullable=True)
    items = db.Column(db.Text, nullable=True)  # JSON string of material items
    total_price = db.Column(db.Numeric(10, 2), nullable=False, default=0)
    include_description_page = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    invoices = db.relationship("Invoice", backref="quotation", lazy=True)
    
    def get_items(self):
        """Parse items JSON string to list"""
        if self.items:
            try:
                return json.loads(self.items)
            except json.JSONDecodeError:
                return []
        return []
    
    def set_items(self, items_list):
        """Convert items list to JSON string"""
        self.items = json.dumps(items_list) if items_list else None
    
    def to_dict(self):
        return {
            "id": self.id,
            "quotation_id": self.quotation_id,
            "client_id": self.client_id,
            "project_id": self.project_id,
            "status": self.status.value if self.status else None,
            "valid_until": self.valid_until.isoformat() if self.valid_until else None,
            "items": self.get_items(),
            "total_price": float(self.total_price) if self.total_price else 0,
            "include_description_page": self.include_description_page,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None
        }


from flask import Blueprint, jsonify, request
from werkzeug.security import generate_password_hash
from src.models.user import User
from src.database import db
from src.middleware.auth import require_auth, require_role
from datetime import datetime
import uuid

user_bp = Blueprint('user', __name__)

@user_bp.route('/users', methods=['GET'])
@require_role('admin')
def get_users():
    """Get all users (admin only)"""
    try:
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 10, type=int)
        search = request.args.get('search', '')
        
        query = User.query
        
        if search:
            query = query.filter(
                User.name.contains(search) |
                User.email.contains(search) |
                User.user_id.contains(search)
            )
        
        users = query.paginate(
            page=page, 
            per_page=per_page, 
            error_out=False
        )
        
        return jsonify({
            'users': [user.to_dict() for user in users.items],
            'pagination': {
                'page': users.page,
                'pages': users.pages,
                'per_page': users.per_page,
                'total': users.total
            }
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@user_bp.route('/users', methods=['POST'])
@require_role('admin')
def create_user():
    """Create a new user (admin only)"""
    try:
        data = request.get_json()
        
        # Validate required fields
        if not data.get('name'):
            return jsonify({'error': 'Name is required'}), 400
        if not data.get('email'):
            return jsonify({'error': 'Email is required'}), 400
        if not data.get('password'):
            return jsonify({'error': 'Password is required'}), 400
        
        # Check if user already exists
        existing_user = User.query.filter_by(email=data['email']).first()
        if existing_user:
            return jsonify({'error': 'User with this email already exists'}), 400
        
        # Generate unique user ID
        user_id = f"USER-{str(uuid.uuid4())[:8].upper()}"
        
        user = User(
            user_id=user_id,
            name=data['name'],
            email=data['email'],
            password_hash=generate_password_hash(data['password']),
            is_active=data.get('is_active', True)
        )
        
        # Set roles if provided
        if data.get('roles'):
            user.set_roles(data['roles'])
        else:
            user.set_roles(['sales'])  # Default role
        
        db.session.add(user)
        db.session.commit()
        
        return jsonify(user.to_dict()), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@user_bp.route('/users/<int:user_id>', methods=['GET'])
@require_auth
def get_user(user_id):
    """Get a specific user"""
    try:
        # Users can only view their own profile unless they're admin
        current_user = request.current_user
        if current_user.id != user_id and not current_user.has_role('admin'):
            return jsonify({'error': 'Access denied'}), 403
        
        user = User.query.get_or_404(user_id)
        return jsonify(user.to_dict())
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@user_bp.route('/users/<int:user_id>', methods=['PUT'])
@require_auth
def update_user(user_id):
    """Update a specific user"""
    try:
        current_user = request.current_user
        user = User.query.get_or_404(user_id)
        data = request.get_json()
        
        # Users can only update their own profile unless they're admin
        if current_user.id != user_id and not current_user.has_role('admin'):
            return jsonify({'error': 'Access denied'}), 403
        
        # Update basic fields
        user.name = data.get('name', user.name)
        
        # Only admin can update email, roles, and active status
        if current_user.has_role('admin'):
            user.email = data.get('email', user.email)
            user.is_active = data.get('is_active', user.is_active)
            if data.get('roles'):
                user.set_roles(data['roles'])
        
        # Update password if provided
        if data.get('password'):
            user.password_hash = generate_password_hash(data['password'])
        
        user.updated_at = datetime.utcnow()
        
        db.session.commit()
        
        return jsonify(user.to_dict())
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@user_bp.route('/users/<int:user_id>', methods=['DELETE'])
@require_role('admin')
def delete_user(user_id):
    """Delete a specific user (admin only)"""
    try:
        user = User.query.get_or_404(user_id)
        
        # Prevent admin from deleting themselves
        current_user = request.current_user
        if current_user.id == user_id:
            return jsonify({'error': 'Cannot delete your own account'}), 400
        
        db.session.delete(user)
        db.session.commit()
        
        return jsonify({'message': 'User deleted successfully'})
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@user_bp.route('/users/<int:user_id>/toggle-status', methods=['POST'])
@require_role('admin')
def toggle_user_status(user_id):
    """Toggle user active status (admin only)"""
    try:
        user = User.query.get_or_404(user_id)
        
        # Prevent admin from deactivating themselves
        current_user = request.current_user
        if current_user.id == user_id:
            return jsonify({'error': 'Cannot deactivate your own account'}), 400
        
        user.is_active = not user.is_active
        user.updated_at = datetime.utcnow()
        
        db.session.commit()
        
        status = 'activated' if user.is_active else 'deactivated'
        return jsonify({
            'message': f'User {status} successfully',
            'user': user.to_dict()
        })
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500


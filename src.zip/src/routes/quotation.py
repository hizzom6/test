from flask import Blueprint, request, jsonify
from src.models.quotation import Quotation, QuotationStatus, db
from src.models.client import Client
from src.models.project import Project
from datetime import datetime, date

quotation_bp = Blueprint('quotation', __name__)

@quotation_bp.route('/quotations', methods=['GET'])
def get_quotations():
    """Get all quotations with pagination"""
    try:
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 10, type=int)
        status = request.args.get('status')
        client_id = request.args.get('client_id', type=int)
        
        query = Quotation.query
        
        if status:
            query = query.filter(Quotation.status == QuotationStatus(status))
        
        if client_id:
            query = query.filter(Quotation.client_id == client_id)
        
        quotations = query.order_by(Quotation.created_at.desc()).paginate(
            page=page, 
            per_page=per_page, 
            error_out=False
        )
        
        return jsonify({
            'quotations': [quotation.to_dict() for quotation in quotations.items],
            'pagination': {
                'page': quotations.page,
                'pages': quotations.pages,
                'per_page': quotations.per_page,
                'total': quotations.total
            }
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@quotation_bp.route('/quotations', methods=['POST'])
def create_quotation():
    """Create a new quotation"""
    try:
        data = request.get_json()
        
        # Validate required fields
        if not data.get('quotation_id'):
            return jsonify({'error': 'Quotation ID is required'}), 400
        if not data.get('client_id'):
            return jsonify({'error': 'Client ID is required'}), 400
        
        # Check if client exists
        client = Client.query.get(data['client_id'])
        if not client:
            return jsonify({'error': 'Client not found'}), 404
        
        quotation = Quotation(
            quotation_id=data['quotation_id'],
            client_id=data['client_id'],
            project_id=data.get('project_id'),
            status=QuotationStatus(data.get('status', 'draft')),
            valid_until=datetime.strptime(data['valid_until'], '%Y-%m-%d').date() if data.get('valid_until') else None,
            total_price=data.get('total_price', 0),
            include_description_page=data.get('include_description_page', False)
        )
        
        # Set items if provided
        if data.get('items'):
            quotation.set_items(data['items'])
        
        db.session.add(quotation)
        db.session.commit()
        
        return jsonify(quotation.to_dict()), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@quotation_bp.route('/quotations/<int:quotation_id>', methods=['GET'])
def get_quotation(quotation_id):
    """Get a specific quotation by ID"""
    try:
        quotation = Quotation.query.get_or_404(quotation_id)
        return jsonify(quotation.to_dict())
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@quotation_bp.route('/quotations/<int:quotation_id>', methods=['PUT'])
def update_quotation(quotation_id):
    """Update a specific quotation"""
    try:
        quotation = Quotation.query.get_or_404(quotation_id)
        data = request.get_json()
        
        # Update fields
        if 'status' in data:
            quotation.status = QuotationStatus(data['status'])
        if 'valid_until' in data:
            quotation.valid_until = datetime.strptime(data['valid_until'], '%Y-%m-%d').date() if data['valid_until'] else None
        if 'total_price' in data:
            quotation.total_price = data['total_price']
        if 'include_description_page' in data:
            quotation.include_description_page = data['include_description_page']
        if 'items' in data:
            quotation.set_items(data['items'])
        
        quotation.updated_at = datetime.utcnow()
        
        db.session.commit()
        
        return jsonify(quotation.to_dict())
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@quotation_bp.route('/quotations/<int:quotation_id>', methods=['DELETE'])
def delete_quotation(quotation_id):
    """Delete a specific quotation"""
    try:
        quotation = Quotation.query.get_or_404(quotation_id)
        db.session.delete(quotation)
        db.session.commit()
        
        return jsonify({'message': 'Quotation deleted successfully'})
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@quotation_bp.route('/quotations/<int:quotation_id>/convert-to-invoice', methods=['POST'])
def convert_to_invoice(quotation_id):
    """Convert quotation to invoice"""
    try:
        from src.models.invoice import Invoice, InvoiceStatus
        
        quotation = Quotation.query.get_or_404(quotation_id)
        data = request.get_json()
        
        # Generate invoice ID
        invoice_count = Invoice.query.count()
        invoice_id = f"INV-{invoice_count + 1:06d}"
        
        # Create invoice from quotation
        invoice = Invoice(
            invoice_id=invoice_id,
            client_id=quotation.client_id,
            project_id=quotation.project_id,
            quotation_id=quotation.id,
            amount_total=quotation.total_price,
            status=InvoiceStatus.UNPAID
        )
        
        db.session.add(invoice)
        db.session.commit()
        
        return jsonify(invoice.to_dict()), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500


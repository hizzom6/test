from functools import wraps
from flask import session, jsonify, request
from src.models.user import User

def require_auth(f):
    """Decorator to require authentication"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            return jsonify({'error': 'Authentication required'}), 401
        
        user = User.query.get(session['user_id'])
        if not user or not user.is_active:
            session.clear()
            return jsonify({'error': 'Invalid or inactive user'}), 401
        
        # Add user to request context
        request.current_user = user
        return f(*args, **kwargs)
    
    return decorated_function

def require_role(*required_roles):
    """Decorator to require specific roles"""
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if 'user_id' not in session:
                return jsonify({'error': 'Authentication required'}), 401
            
            user = User.query.get(session['user_id'])
            if not user or not user.is_active:
                session.clear()
                return jsonify({'error': 'Invalid or inactive user'}), 401
            
            user_roles = user.get_roles()
            
            # Admin can access everything
            if 'admin' in user_roles:
                request.current_user = user
                return f(*args, **kwargs)
            
            # Check if user has any of the required roles
            if not any(role in user_roles for role in required_roles):
                return jsonify({'error': 'Insufficient permissions'}), 403
            
            request.current_user = user
            return f(*args, **kwargs)
        
        return decorated_function
    return decorator

def require_permission(action, entity_type):
    """Decorator to require specific permission"""
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if 'user_id' not in session:
                return jsonify({'error': 'Authentication required'}), 401
            
            user = User.query.get(session['user_id'])
            if not user or not user.is_active:
                session.clear()
                return jsonify({'error': 'Invalid or inactive user'}), 401
            
            has_permission = False
            
            if action == 'create':
                has_permission = user.can_create(entity_type)
            elif action == 'edit':
                has_permission = user.can_edit(entity_type)
            elif action == 'view':
                has_permission = user.can_view(entity_type)
            elif action == 'delete':
                has_permission = user.has_role('admin')
            
            if not has_permission:
                return jsonify({'error': f'No permission to {action} {entity_type}'}), 403
            
            request.current_user = user
            return f(*args, **kwargs)
        
        return decorated_function
    return decorator


from flask import Blueprint, request, jsonify
from src.models.client import Client
from src.models.user import User
from src.database import db
from src.middleware.auth import require_auth, require_permission
from datetime import datetime

client_bp = Blueprint('client', __name__)

@client_bp.route('/clients', methods=['GET'])
@require_permission('view', 'client')
def get_clients():
    """Get all clients with pagination"""
    try:
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 10, type=int)
        search = request.args.get('search', '')
        
        query = Client.query
        
        if search:
            query = query.filter(
                Client.client_name.contains(search) |
                Client.contact_person.contains(search) |
                Client.email_1.contains(search)
            )
        
        clients = query.paginate(
            page=page, 
            per_page=per_page, 
            error_out=False
        )
        
        return jsonify({
            'clients': [client.to_dict() for client in clients.items],
            'pagination': {
                'page': clients.page,
                'pages': clients.pages,
                'per_page': clients.per_page,
                'total': clients.total
            }
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@client_bp.route('/clients', methods=['POST'])
@require_permission('create', 'client')
def create_client():
    """Create a new client"""
    try:
        data = request.get_json()
        
        # Validate required fields
        if not data.get('client_name'):
            return jsonify({'error': 'Client name is required'}), 400
        
        client = Client(
            client_name=data['client_name'],
            city=data.get('city'),
            location=data.get('location'),
            contact_person=data.get('contact_person'),
            email_1=data.get('email_1'),
            email_2=data.get('email_2'),
            phone_1=data.get('phone_1'),
            phone_2=data.get('phone_2'),
            notes=data.get('notes')
        )
        
        db.session.add(client)
        db.session.commit()
        
        return jsonify(client.to_dict()), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@client_bp.route('/clients/<int:client_id>', methods=['GET'])
@require_permission('view', 'client')
def get_client(client_id):
    """Get a specific client by ID"""
    try:
        client = Client.query.get_or_404(client_id)
        return jsonify(client.to_dict())
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@client_bp.route('/clients/<int:client_id>', methods=['PUT'])
@require_permission('edit', 'client')
def update_client(client_id):
    """Update a specific client"""
    try:
        client = Client.query.get_or_404(client_id)
        data = request.get_json()
        
        # Update fields
        client.client_name = data.get('client_name', client.client_name)
        client.city = data.get('city', client.city)
        client.location = data.get('location', client.location)
        client.contact_person = data.get('contact_person', client.contact_person)
        client.email_1 = data.get('email_1', client.email_1)
        client.email_2 = data.get('email_2', client.email_2)
        client.phone_1 = data.get('phone_1', client.phone_1)
        client.phone_2 = data.get('phone_2', client.phone_2)
        client.notes = data.get('notes', client.notes)
        client.updated_at = datetime.utcnow()
        
        db.session.commit()
        
        return jsonify(client.to_dict())
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@client_bp.route('/clients/<int:client_id>', methods=['DELETE'])
@require_permission('delete', 'client')
def delete_client(client_id):
    """Delete a specific client"""
    try:
        client = Client.query.get_or_404(client_id)
        db.session.delete(client)
        db.session.commit()
        
        return jsonify({'message': 'Client deleted successfully'})
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500


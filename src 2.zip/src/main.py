import os
import sys
# DON'T CHANGE THIS !!!
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from flask import Flask, send_from_directory
from flask_cors import CORS
from src.database import db

# Import all models to ensure they are registered with SQLAlchemy
from src.models.user import User
from src.models.client import Client
from src.models.project import Project
from src.models.material import Material
from src.models.quotation import Quotation
from src.models.invoice import Invoice
from src.models.payment_tracker import PaymentTracker
from src.models.project_budget import ProjectBudget

from src.routes.auth import auth_bp
from src.routes.user import user_bp
from src.routes.client import client_bp
from src.routes.quotation import quotation_bp
from src.routes.invoice import invoice_bp
from src.routes.material import material_bp
from src.routes.project import project_bp

app = Flask(__name__, static_folder=os.path.join(os.path.dirname(__file__), 'static'))
app.config['SECRET_KEY'] = 'asdf#FGSgvasgf$5$WGT'

# Session configuration
app.config['SESSION_TYPE'] = 'filesystem'
app.config['SESSION_PERMANENT'] = False
app.config['SESSION_USE_SIGNER'] = True
app.config['SESSION_KEY_PREFIX'] = 'landscaping:'

# Enable CORS for all routes with credentials support
CORS(app, origins="*", supports_credentials=True)

# Register blueprints
app.register_blueprint(auth_bp, url_prefix='/api/auth')
app.register_blueprint(user_bp, url_prefix='/api')
app.register_blueprint(client_bp, url_prefix='/api')
app.register_blueprint(quotation_bp, url_prefix='/api')
app.register_blueprint(invoice_bp, url_prefix='/api')
app.register_blueprint(material_bp, url_prefix='/api')
app.register_blueprint(project_bp, url_prefix='/api')

# Database configuration
app.config['SQLALCHEMY_DATABASE_URI'] = f"sqlite:///{os.path.join(os.path.dirname(__file__), 'database', 'app.db')}"
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db.init_app(app)

with app.app_context():
    db.create_all()
    
    # Create default admin user if it doesn't exist
    admin_user = User.query.filter_by(email='admin@landscaping.com').first()
    if not admin_user:
        from werkzeug.security import generate_password_hash
        import uuid
        
        admin = User(
            user_id=f"ADMIN-{str(uuid.uuid4())[:8].upper()}",
            name='System Administrator',
            email='admin@landscaping.com',
            password_hash=generate_password_hash('admin123'),
            is_active=True
        )
        admin.set_roles(['admin'])
        
        db.session.add(admin)
        db.session.commit()
        print("Default admin user created: admin@landscaping.com / admin123")

@app.route('/', defaults={'path': ''})
@app.route('/<path:path>')
def serve(path):
    static_folder_path = app.static_folder
    if static_folder_path is None:
            return "Static folder not configured", 404

    if path != "" and os.path.exists(os.path.join(static_folder_path, path)):
        return send_from_directory(static_folder_path, path)
    else:
        index_path = os.path.join(static_folder_path, 'index.html')
        if os.path.exists(index_path):
            return send_from_directory(static_folder_path, 'index.html')
        else:
            return "index.html not found", 404


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)


from src.database import db
from datetime import datetime

class PaymentTracker(db.Model):
    __tablename__ = "payment_trackers"
    
    id = db.Column(db.Integer, primary_key=True)
    client_id = db.Column(db.Integer, db.ForeignKey("clients.id"), nullable=False)
    project_id = db.Column(db.Integer, db.ForeignKey("projects.id"), nullable=True)
    total_invoiced = db.Column(db.Numeric(10, 2), default=0)
    amount_paid = db.Column(db.Numeric(10, 2), default=0)
    remaining_balance = db.Column(db.Numeric(10, 2), default=0)
    next_payment_due = db.Column(db.Date, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def to_dict(self):
        return {
            "id": self.id,
            "client_id": self.client_id,
            "project_id": self.project_id,
            "total_invoiced": float(self.total_invoiced) if self.total_invoiced else 0,
            "amount_paid": float(self.amount_paid) if self.amount_paid else 0,
            "remaining_balance": float(self.remaining_balance) if self.remaining_balance else 0,
            "next_payment_due": self.next_payment_due.isoformat() if self.next_payment_due else None,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None
        }


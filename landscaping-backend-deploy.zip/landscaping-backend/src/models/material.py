from src.database import db
from datetime import datetime

class Material(db.Model):
    __tablename__ = "materials"
    
    id = db.Column(db.Integer, primary_key=True)
    material_id = db.Column(db.String(100), unique=True, nullable=False)
    name = db.Column(db.String(255), nullable=False)
    description = db.Column(db.Text, nullable=True)
    cost_price = db.Column(db.Numeric(10, 2), nullable=False)
    retail_price = db.Column(db.Numeric(10, 2), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def to_dict(self):
        return {
            "id": self.id,
            "material_id": self.material_id,
            "name": self.name,
            "description": self.description,
            "cost_price": float(self.cost_price) if self.cost_price else 0,
            "retail_price": float(self.retail_price) if self.retail_price else 0,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None
        }


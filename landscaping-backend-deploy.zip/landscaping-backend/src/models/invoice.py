from src.database import db
from datetime import datetime
import enum

class InvoiceStatus(enum.Enum):
    UNPAID = "unpaid"
    PARTIALLY_PAID = "partially_paid"
    PAID = "paid"

class Invoice(db.Model):
    __tablename__ = "invoices"
    
    id = db.Column(db.Integer, primary_key=True)
    invoice_id = db.Column(db.String(100), unique=True, nullable=False)
    client_id = db.Column(db.Integer, db.ForeignKey("clients.id"), nullable=False)
    project_id = db.Column(db.Integer, db.ForeignKey("projects.id"), nullable=True)
    quotation_id = db.Column(db.Integer, db.ForeignKey("quotations.id"), nullable=True)
    amount_total = db.Column(db.Numeric(10, 2), nullable=False)
    amount_paid = db.Column(db.Numeric(10, 2), default=0)
    payment_due_date = db.Column(db.Date, nullable=True)
    status = db.Column(db.Enum(InvoiceStatus), nullable=False, default=InvoiceStatus.UNPAID)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def to_dict(self):
        return {
            "id": self.id,
            "invoice_id": self.invoice_id,
            "client_id": self.client_id,
            "project_id": self.project_id,
            "quotation_id": self.quotation_id,
            "amount_total": float(self.amount_total) if self.amount_total else 0,
            "amount_paid": float(self.amount_paid) if self.amount_paid else 0,
            "payment_due_date": self.payment_due_date.isoformat() if self.payment_due_date else None,
            "status": self.status.value if self.status else None,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None
        }


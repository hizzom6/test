from flask import Blueprint, request, jsonify
from src.models.invoice import Invoice, InvoiceStatus, db
from src.models.client import Client
from src.models.payment_tracker import PaymentTracker
from datetime import datetime

invoice_bp = Blueprint('invoice', __name__)

@invoice_bp.route('/invoices', methods=['GET'])
def get_invoices():
    """Get all invoices with pagination"""
    try:
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 10, type=int)
        status = request.args.get('status')
        client_id = request.args.get('client_id', type=int)
        
        query = Invoice.query
        
        if status:
            query = query.filter(Invoice.status == InvoiceStatus(status))
        
        if client_id:
            query = query.filter(Invoice.client_id == client_id)
        
        invoices = query.order_by(Invoice.created_at.desc()).paginate(
            page=page, 
            per_page=per_page, 
            error_out=False
        )
        
        return jsonify({
            'invoices': [invoice.to_dict() for invoice in invoices.items],
            'pagination': {
                'page': invoices.page,
                'pages': invoices.pages,
                'per_page': invoices.per_page,
                'total': invoices.total
            }
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@invoice_bp.route('/invoices', methods=['POST'])
def create_invoice():
    """Create a new invoice"""
    try:
        data = request.get_json()
        
        # Validate required fields
        if not data.get('invoice_id'):
            return jsonify({'error': 'Invoice ID is required'}), 400
        if not data.get('client_id'):
            return jsonify({'error': 'Client ID is required'}), 400
        if not data.get('amount_total'):
            return jsonify({'error': 'Amount total is required'}), 400
        
        # Check if client exists
        client = Client.query.get(data['client_id'])
        if not client:
            return jsonify({'error': 'Client not found'}), 404
        
        invoice = Invoice(
            invoice_id=data['invoice_id'],
            client_id=data['client_id'],
            project_id=data.get('project_id'),
            quotation_id=data.get('quotation_id'),
            amount_total=data['amount_total'],
            amount_paid=data.get('amount_paid', 0),
            payment_due_date=datetime.strptime(data['payment_due_date'], '%Y-%m-%d').date() if data.get('payment_due_date') else None,
            status=InvoiceStatus(data.get('status', 'unpaid'))
        )
        
        db.session.add(invoice)
        db.session.commit()
        
        # Update payment tracker
        update_payment_tracker(invoice.client_id, invoice.project_id)
        
        return jsonify(invoice.to_dict()), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@invoice_bp.route('/invoices/<int:invoice_id>', methods=['GET'])
def get_invoice(invoice_id):
    """Get a specific invoice by ID"""
    try:
        invoice = Invoice.query.get_or_404(invoice_id)
        return jsonify(invoice.to_dict())
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@invoice_bp.route('/invoices/<int:invoice_id>', methods=['PUT'])
def update_invoice(invoice_id):
    """Update a specific invoice"""
    try:
        invoice = Invoice.query.get_or_404(invoice_id)
        data = request.get_json()
        
        # Update fields
        if 'amount_paid' in data:
            invoice.amount_paid = data['amount_paid']
            # Update status based on payment
            if invoice.amount_paid >= invoice.amount_total:
                invoice.status = InvoiceStatus.PAID
            elif invoice.amount_paid > 0:
                invoice.status = InvoiceStatus.PARTIALLY_PAID
            else:
                invoice.status = InvoiceStatus.UNPAID
        
        if 'payment_due_date' in data:
            invoice.payment_due_date = datetime.strptime(data['payment_due_date'], '%Y-%m-%d').date() if data['payment_due_date'] else None
        
        if 'status' in data:
            invoice.status = InvoiceStatus(data['status'])
        
        invoice.updated_at = datetime.utcnow()
        
        db.session.commit()
        
        # Update payment tracker
        update_payment_tracker(invoice.client_id, invoice.project_id)
        
        return jsonify(invoice.to_dict())
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@invoice_bp.route('/invoices/<int:invoice_id>', methods=['DELETE'])
def delete_invoice(invoice_id):
    """Delete a specific invoice"""
    try:
        invoice = Invoice.query.get_or_404(invoice_id)
        client_id = invoice.client_id
        project_id = invoice.project_id
        
        db.session.delete(invoice)
        db.session.commit()
        
        # Update payment tracker
        update_payment_tracker(client_id, project_id)
        
        return jsonify({'message': 'Invoice deleted successfully'})
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

def update_payment_tracker(client_id, project_id):
    """Update payment tracker for a client/project"""
    try:
        # Get or create payment tracker
        tracker = PaymentTracker.query.filter_by(
            client_id=client_id, 
            project_id=project_id
        ).first()
        
        if not tracker:
            tracker = PaymentTracker(
                client_id=client_id,
                project_id=project_id
            )
            db.session.add(tracker)
        
        # Calculate totals from invoices
        invoices = Invoice.query.filter_by(
            client_id=client_id,
            project_id=project_id
        ).all()
        
        total_invoiced = sum(float(inv.amount_total) for inv in invoices)
        amount_paid = sum(float(inv.amount_paid) for inv in invoices)
        remaining_balance = total_invoiced - amount_paid
        
        # Find next payment due date
        next_payment_due = None
        unpaid_invoices = [inv for inv in invoices if inv.status != InvoiceStatus.PAID and inv.payment_due_date]
        if unpaid_invoices:
            next_payment_due = min(inv.payment_due_date for inv in unpaid_invoices)
        
        # Update tracker
        tracker.total_invoiced = total_invoiced
        tracker.amount_paid = amount_paid
        tracker.remaining_balance = remaining_balance
        tracker.next_payment_due = next_payment_due
        tracker.updated_at = datetime.utcnow()
        
        db.session.commit()
        
    except Exception as e:
        print(f"Error updating payment tracker: {e}")
        db.session.rollback()


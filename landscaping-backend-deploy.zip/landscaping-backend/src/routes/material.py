from flask import Blueprint, request, jsonify
from src.models.material import Material, db
from datetime import datetime

material_bp = Blueprint('material', __name__)

@material_bp.route('/materials', methods=['GET'])
def get_materials():
    """Get all materials with pagination"""
    try:
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 10, type=int)
        search = request.args.get('search', '')
        
        query = Material.query
        
        if search:
            query = query.filter(
                Material.name.contains(search) |
                Material.description.contains(search) |
                Material.material_id.contains(search)
            )
        
        materials = query.order_by(Material.name).paginate(
            page=page, 
            per_page=per_page, 
            error_out=False
        )
        
        return jsonify({
            'materials': [material.to_dict() for material in materials.items],
            'pagination': {
                'page': materials.page,
                'pages': materials.pages,
                'per_page': materials.per_page,
                'total': materials.total
            }
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@material_bp.route('/materials', methods=['POST'])
def create_material():
    """Create a new material"""
    try:
        data = request.get_json()
        
        # Validate required fields
        if not data.get('material_id'):
            return jsonify({'error': 'Material ID is required'}), 400
        if not data.get('name'):
            return jsonify({'error': 'Material name is required'}), 400
        if not data.get('cost_price'):
            return jsonify({'error': 'Cost price is required'}), 400
        if not data.get('retail_price'):
            return jsonify({'error': 'Retail price is required'}), 400
        
        material = Material(
            material_id=data['material_id'],
            name=data['name'],
            description=data.get('description'),
            cost_price=data['cost_price'],
            retail_price=data['retail_price']
        )
        
        db.session.add(material)
        db.session.commit()
        
        return jsonify(material.to_dict()), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@material_bp.route('/materials/<int:material_id>', methods=['GET'])
def get_material(material_id):
    """Get a specific material by ID"""
    try:
        material = Material.query.get_or_404(material_id)
        return jsonify(material.to_dict())
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@material_bp.route('/materials/<int:material_id>', methods=['PUT'])
def update_material(material_id):
    """Update a specific material"""
    try:
        material = Material.query.get_or_404(material_id)
        data = request.get_json()
        
        # Update fields
        material.name = data.get('name', material.name)
        material.description = data.get('description', material.description)
        material.cost_price = data.get('cost_price', material.cost_price)
        material.retail_price = data.get('retail_price', material.retail_price)
        material.updated_at = datetime.utcnow()
        
        db.session.commit()
        
        return jsonify(material.to_dict())
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@material_bp.route('/materials/<int:material_id>', methods=['DELETE'])
def delete_material(material_id):
    """Delete a specific material"""
    try:
        material = Material.query.get_or_404(material_id)
        db.session.delete(material)
        db.session.commit()
        
        return jsonify({'message': 'Material deleted successfully'})
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500


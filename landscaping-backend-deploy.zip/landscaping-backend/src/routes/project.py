from flask import Blueprint, request, jsonify
from src.models.project import Project, ProjectStatus, db
from src.models.client import Client
from src.models.user import User
from src.models.project_budget import ProjectBudget
from datetime import datetime

project_bp = Blueprint('project', __name__)

@project_bp.route('/projects', methods=['GET'])
def get_projects():
    """Get all projects with pagination"""
    try:
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 10, type=int)
        status = request.args.get('status')
        client_id = request.args.get('client_id', type=int)
        engineer_id = request.args.get('engineer_id', type=int)
        
        query = Project.query
        
        if status:
            query = query.filter(Project.status == ProjectStatus(status))
        
        if client_id:
            query = query.filter(Project.client_id == client_id)
            
        if engineer_id:
            query = query.filter(Project.assigned_engineer_id == engineer_id)
        
        projects = query.order_by(Project.created_at.desc()).paginate(
            page=page, 
            per_page=per_page, 
            error_out=False
        )
        
        return jsonify({
            'projects': [project.to_dict() for project in projects.items],
            'pagination': {
                'page': projects.page,
                'pages': projects.pages,
                'per_page': projects.per_page,
                'total': projects.total
            }
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@project_bp.route('/projects', methods=['POST'])
def create_project():
    """Create a new project"""
    try:
        data = request.get_json()
        
        # Validate required fields
        if not data.get('project_id'):
            return jsonify({'error': 'Project ID is required'}), 400
        if not data.get('client_id'):
            return jsonify({'error': 'Client ID is required'}), 400
        
        # Check if client exists
        client = Client.query.get(data['client_id'])
        if not client:
            return jsonify({'error': 'Client not found'}), 404
        
        # Check if engineer exists (if provided)
        if data.get('assigned_engineer_id'):
            engineer = User.query.get(data['assigned_engineer_id'])
            if not engineer:
                return jsonify({'error': 'Engineer not found'}), 404
        
        project = Project(
            project_id=data['project_id'],
            client_id=data['client_id'],
            status=ProjectStatus(data.get('status', 'quoted')),
            start_date=datetime.strptime(data['start_date'], '%Y-%m-%d').date() if data.get('start_date') else None,
            end_date=datetime.strptime(data['end_date'], '%Y-%m-%d').date() if data.get('end_date') else None,
            progress_percentage=data.get('progress_percentage', 0.0),
            assigned_engineer_id=data.get('assigned_engineer_id')
        )
        
        db.session.add(project)
        db.session.commit()
        
        return jsonify(project.to_dict()), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@project_bp.route('/projects/<int:project_id>', methods=['GET'])
def get_project(project_id):
    """Get a specific project by ID"""
    try:
        project = Project.query.get_or_404(project_id)
        return jsonify(project.to_dict())
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@project_bp.route('/projects/<int:project_id>', methods=['PUT'])
def update_project(project_id):
    """Update a specific project"""
    try:
        project = Project.query.get_or_404(project_id)
        data = request.get_json()
        
        # Update fields
        if 'status' in data:
            project.status = ProjectStatus(data['status'])
        if 'start_date' in data:
            project.start_date = datetime.strptime(data['start_date'], '%Y-%m-%d').date() if data['start_date'] else None
        if 'end_date' in data:
            project.end_date = datetime.strptime(data['end_date'], '%Y-%m-%d').date() if data['end_date'] else None
        if 'progress_percentage' in data:
            project.progress_percentage = data['progress_percentage']
        if 'assigned_engineer_id' in data:
            project.assigned_engineer_id = data['assigned_engineer_id']
        
        project.updated_at = datetime.utcnow()
        
        db.session.commit()
        
        return jsonify(project.to_dict())
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@project_bp.route('/projects/<int:project_id>', methods=['DELETE'])
def delete_project(project_id):
    """Delete a specific project"""
    try:
        project = Project.query.get_or_404(project_id)
        db.session.delete(project)
        db.session.commit()
        
        return jsonify({'message': 'Project deleted successfully'})
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@project_bp.route('/projects/<int:project_id>/budget', methods=['GET'])
def get_project_budget(project_id):
    """Get project budget"""
    try:
        budget = ProjectBudget.query.filter_by(project_id=project_id).first()
        if not budget:
            return jsonify({'error': 'Budget not found'}), 404
        
        return jsonify(budget.to_dict())
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@project_bp.route('/projects/<int:project_id>/budget', methods=['POST'])
def create_project_budget(project_id):
    """Create project budget"""
    try:
        data = request.get_json()
        
        # Check if project exists
        project = Project.query.get(project_id)
        if not project:
            return jsonify({'error': 'Project not found'}), 404
        
        # Check if budget already exists
        existing_budget = ProjectBudget.query.filter_by(project_id=project_id).first()
        if existing_budget:
            return jsonify({'error': 'Budget already exists for this project'}), 400
        
        budget = ProjectBudget(
            project_id=project_id,
            assigned_by=data['assigned_by'],
            material_budget_total=data['material_budget_total'],
            actual_expenses=data.get('actual_expenses', 0),
            remaining_budget=data['material_budget_total'] - data.get('actual_expenses', 0)
        )
        
        db.session.add(budget)
        db.session.commit()
        
        return jsonify(budget.to_dict()), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@project_bp.route('/projects/<int:project_id>/budget', methods=['PUT'])
def update_project_budget(project_id):
    """Update project budget"""
    try:
        budget = ProjectBudget.query.filter_by(project_id=project_id).first()
        if not budget:
            return jsonify({'error': 'Budget not found'}), 404
        
        data = request.get_json()
        
        # Update fields
        if 'material_budget_total' in data:
            budget.material_budget_total = data['material_budget_total']
        if 'actual_expenses' in data:
            budget.actual_expenses = data['actual_expenses']
        
        # Recalculate remaining budget
        budget.remaining_budget = budget.material_budget_total - budget.actual_expenses
        budget.updated_at = datetime.utcnow()
        
        db.session.commit()
        
        return jsonify(budget.to_dict())
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

